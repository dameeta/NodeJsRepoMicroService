let properties = require("../package.json");
let distance = require("../service/distance");
let weather = require("../service/weather");

let controllers = {
    about:(req,res)=>{
        let aboutInfo ={
            name:properties.name,
            description:properties.description,
            author:properties.author
        }
        res.json(aboutInfo);
    },
    getDistance: function(res,req){
        distance.find(req,res,function(err,dist){
            if(err)
                res.send(err);
            res.json(dist);
        });
    },
    getWeather: function(req,res){

        weather.find(req,res,function(err,weath){

            if(err)
                res.send(err);
            res.json(weath);
        });
    },

};
module.exports =controllers;