const controller = require("./controller");

module.exports = function(weatherApp){
weatherApp.route("/about")
    .get(controller.about);
weatherApp.route("/distance")
    .get(controller.getDistance);
weatherApp.route("/weather")
    .get(controller.getWeather);


};









